import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  implements OnInit  {
  title = 'testApp';
constructor() {
}
ngOnInit(): void {
  const timer = Observable.timer(0, 10000);

  timer.subscribe(tick => {
    this.callToAPI();
  });

}

callToAPI() {
 // write you code to create connection to API
  console.log('I am working');
}
}
